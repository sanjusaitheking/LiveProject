package com.example.StudentManagementSystem.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.StudentManagementSystem.entities.Student;
import com.example.StudentManagementSystem.util.HibernetUtil;

public class StudentDao {

	public void saveStudent(Student student) {
		Transaction transaction = null;

		System.out.println("Hibernate Util "+student);
		try (Session session = HibernetUtil.getSessionFactory().openSession()) {
			// start transaction
			transaction = session.beginTransaction();

			// save student object
			session.save(student);

			// commit transaction
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

	}
	
	public List<Student> getStudents()
	{
		try(Session session=HibernetUtil.getSessionFactory().openSession())
		{
			System.out.println(session);
			return session.createQuery("From Student",Student.class).list();
		}
		
	}

}
