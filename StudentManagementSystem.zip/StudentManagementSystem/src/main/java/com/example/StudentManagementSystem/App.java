package com.example.StudentManagementSystem;

import java.util.List;

import com.example.StudentManagementSystem.dao.StudentDao;
import com.example.StudentManagementSystem.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Student s1=new Student("Sachin","Tendulkar","sachin@gmail.com");
        Student s2=new Student("Virat","Kohli","virat@gmail.com");
        
        StudentDao stdao=new StudentDao();
        
        stdao.saveStudent(s1);
        stdao.saveStudent(s2);
        
        List<Student> students=stdao.getStudents();
        
        for(Student s:students)
        	System.out.println(s.getFirstName()+" "+s.getLastName()+" "+s.getEmail());
        
        
        
    }
}
